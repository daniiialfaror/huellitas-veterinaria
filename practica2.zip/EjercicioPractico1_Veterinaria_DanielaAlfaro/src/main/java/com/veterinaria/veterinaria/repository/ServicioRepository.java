/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.veterinaria.veterinaria.repository;

/**
 *
 * @author dania
 */
import com.veterinaria.veterinaria.domain.Servicio;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ServicioRepository extends JpaRepository<Servicio, Long> {

    // Consulta ampliada de servicios y tipos de servicio
    @Query("""
           SELECT s
           FROM Servicio s
           JOIN FETCH s.tipoServicio
           ORDER BY s.tipoServicio.nombre ASC, s.nombre ASC
           """)
    List<Servicio> consultarServiciosAmpliados();

}